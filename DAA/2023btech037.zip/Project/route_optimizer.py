import pandas as pd
import networkx as nx
import heapq
import tkinter as tk
from tkinter import ttk, messagebox
import os

# Load Graph from CSV File
def load_graph(file_path="routes.csv"):
    file_path = os.path.join(os.path.dirname(__file__), file_path)
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"CSV file not found: {file_path}")
    
    graph = nx.Graph()
    data = pd.read_csv(file_path)

    for _, row in data.iterrows():
        graph.add_edge(row["Source"], row["Destination"], 
                       distance=row["Distance"], 
                       tolls=row["Tolls"], 
                       traffic=row["Traffic"], 
                       road_quality=row["Road_Quality"], 
                       hotel_cost=row["Hotel_Cost"], 
                       aesthetics=row["Aesthetics"])
    return graph

# Optimization Functions
def cost_function(graph, start, end, mileage=15, fuel_cost=5):
    edge = graph[start][end]
    fuel_needed = edge['distance'] / mileage
    cost = fuel_needed * fuel_cost + (edge['tolls'] * 10) + edge['hotel_cost']
    print(f"Cost Calculation ({start} -> {end}): Fuel: {fuel_needed*fuel_cost}₹ + Tolls: {edge['tolls']*10}₹ + Hotels: {edge['hotel_cost']}₹ = {cost}₹")
    return cost

def time_function(graph, start, end, avg_speed=60):
    edge = graph[start][end]
    time = (edge['distance'] / avg_speed) + edge['traffic']
    print(f"Time Calculation ({start} -> {end}): Distance: {edge['distance']} km / Speed: {avg_speed} km/hr + Traffic: {edge['traffic']} hrs = {time} hrs")
    return time

def satisfaction_function(graph, start, end, alpha=1, beta=1, gamma=1):
    edge = graph[start][end]
    satisfaction = -(alpha * edge['aesthetics'] + beta * edge['road_quality'] - gamma * edge['traffic'])
    print(f"Satisfaction Calculation ({start} -> {end}): Aesthetics: {edge['aesthetics']} + Road Quality: {edge['road_quality']} - Traffic: {edge['traffic']} = {satisfaction}")
    return satisfaction

# Dijkstra’s Algorithm for Optimal Route Calculation
def dijkstra(graph, source, destination, weight_function, *args):
    pq = []
    heapq.heappush(pq, (0, source))
    distances = {node: float('inf') for node in graph}
    distances[source] = 0
    previous_nodes = {node: None for node in graph}

    while pq:
        current_weight, current_node = heapq.heappop(pq)
        if current_node == destination:
            break

        for neighbor in graph.neighbors(current_node):
            weight = weight_function(graph, current_node, neighbor, *args)
            new_weight = current_weight + weight

            if new_weight < distances[neighbor]:
                distances[neighbor] = new_weight
                previous_nodes[neighbor] = current_node
                heapq.heappush(pq, (new_weight, neighbor))

    path = []
    current = destination
    while current is not None:
        path.append(current)
        current = previous_nodes[current]

    return path[::-1], distances[destination]

def find_best_route(graph, start, end, mode, mileage, fuel_cost, avg_speed):
    if mode == "cost":
        weight_function = cost_function
        args = (mileage, fuel_cost)
    elif mode == "time":
        weight_function = time_function
        args = (avg_speed,)
    elif mode == "satisfaction":
        weight_function = satisfaction_function
        args = ()
    else:
        raise ValueError("Invalid mode")

    return dijkstra(graph, start, end, weight_function, *args)

# GUI Application
class RouteOptimizerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Multi-Criteria Route Optimization")
        self.graph = load_graph()

        tk.Label(root, text="Select Start City:").grid(row=0, column=0)
        self.start_var = ttk.Combobox(root, values=list(self.graph.nodes))
        self.start_var.grid(row=0, column=1)

        tk.Label(root, text="Select Destination:").grid(row=1, column=0)
        self.dest_var = ttk.Combobox(root, values=list(self.graph.nodes))
        self.dest_var.grid(row=1, column=1)

        tk.Label(root, text="Optimization Preference:").grid(row=2, column=0)
        self.opt_var = ttk.Combobox(root, values=["Cost", "Time", "Satisfaction"])
        self.opt_var.grid(row=2, column=1)

        tk.Label(root, text="Mileage (km/l):").grid(row=3, column=0)
        self.mileage_entry = tk.Entry(root)
        self.mileage_entry.insert(0, "15")
        self.mileage_entry.grid(row=3, column=1)

        tk.Label(root, text="Fuel Cost (₹/l):").grid(row=4, column=0)
        self.fuel_cost_entry = tk.Entry(root)
        self.fuel_cost_entry.insert(0, "5")
        self.fuel_cost_entry.grid(row=4, column=1)

        tk.Label(root, text="Average Speed (km/h):").grid(row=5, column=0)
        self.speed_entry = tk.Entry(root)
        self.speed_entry.insert(0, "60")
        self.speed_entry.grid(row=5, column=1)

        self.button = tk.Button(root, text="Find Route", command=self.calculate_route)
        self.button.grid(row=6, column=0, columnspan=2)

    def calculate_route(self):
        start = self.start_var.get()
        end = self.dest_var.get()
        mode = self.opt_var.get().lower()
        
        if not start or not end or not mode:
            messagebox.showerror("Error", "Please select all fields.")
            return

        mileage = float(self.mileage_entry.get())
        fuel_cost = float(self.fuel_cost_entry.get())
        avg_speed = float(self.speed_entry.get())

        path, cost = find_best_route(self.graph, start, end, mode, mileage, fuel_cost, avg_speed)
        
        messagebox.showinfo("Optimal Route", f"Route: {' -> '.join(path)}\n{mode.capitalize()}: {cost:.2f}")

if __name__ == "__main__":
    root = tk.Tk()
    app = RouteOptimizerApp(root)
    root.mainloop()
